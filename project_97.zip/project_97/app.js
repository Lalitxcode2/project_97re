function login(){
    user_name1 = document.getElementById("name").value;
    
    localStorage.setItem("user name",user_name1);
    
     window.location= "secondpage.html";
    }