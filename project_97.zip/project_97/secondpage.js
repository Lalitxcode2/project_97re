const firebaseConfig = {
    apiKey: "AIzaSyDK-poAKdKat_fBX52Oh16BPKajxAi4Iaw",
    authDomain: "save-water-94ddc.firebaseapp.com",
    databaseURL: "https://save-water-94ddc-default-rtdb.firebaseio.com",
    projectId: "save-water-94ddc",
    storageBucket: "save-water-94ddc.appspot.com",
    messagingSenderId: "731357836374",
    appId: "1:731357836374:web:6adf9b721be69422af37f7"
  };

  firebase.initializeApp(firebaseConfig);

    room_name=localStorage.getItem("room name");
    get_username = localStorage.getItem("user name");

    function send(){
        firebase.database().ref("/").child(room_name).update({
            purpose:"adding room name"
        });
        msg=document.getElementById("msg").value;
        firebase.database().ref(room_name).push({
              name: get_username,
              message:msg
        })
        window.location= "thirdpage.html"};

        function logout(){
            window.location= "index.html";
            }